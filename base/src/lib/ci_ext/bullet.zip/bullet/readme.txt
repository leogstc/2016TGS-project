At the moment there are no binary packages from Bullet library.
Once this is done, the libraries will be placed here

LinearMath
BulletCollision
BulletDynamics

The C-API will be available in the include folder.

For now, there is only C++ files, see src/btBulletCollisionCommon.h and src/btBulletDynamicsCommon.h

http://bullet.googlecode.com
Erwin Coumans
